#include <stdio.h>
#include <math.h>

// MyHealth BMI Tracker
float weight = 0.0;
float height = 0.0;


// Function to add record
void addRecord() {
    printf("\nEnter Weight (kg): ");
    scanf("%f", &weight);

    printf("Enter Height (meters): ");
    scanf("%f", &height);

    printf("Record added successfully\n");
}

// Function to view record
void viewRecord() {
    if (weight == 0.0 && height == 0.0) {
        printf("\nNo record found. Please add a record first.\n");
    } else {
        printf("\nStored BMI:\n");
        printf("Weight: %.2f kg\n", weight);
        printf("Height: %.2f m\n", height);
    }
}

// Function to calculate BMI
void calculateBMI() {
    if (weight == 0.0 && height == 0.0) {
        printf("\nNo record to analyze. Please add a record first.\n");
        return;
    }

    float bmi = weight / (height * height);

    printf("\nBMI Analysis:\n");
    printf("Your BMI: %.2f\n", bmi);

    if (bmi < 18.5) {
        printf("BMI Category: Underweight\n");
    }
    else if (bmi >= 18.5 && bmi <= 24.9) {
        printf("BMI Category: Normal weight\n");
    }
    else if (bmi >= 25.0 && bmi <= 29.9) {
        printf("BMI Category: Overweight\n");
    }
    else if (bmi >= 30.0) {
        printf("BMI Category: Obese\n");
    }
}

// Main function
int main() {
    int choice;

    do {
        printf("\n===== MyHealth BMI Tracker =====\n");
        printf("1. Add Record\n");
        printf("2. View Record\n");
        printf("3. calculate BMI\n");
        printf("4. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        if (choice == 1) {
            addRecord();
        }
        else if (choice == 2) {
            viewRecord();
        }
        else if (choice == 3) {
            calculateBMI();
        }
        else if (choice == 4) {
            printf("Exiting program... Goodbye!\n");
        }
        else {
            printf("Invalid choice. Please try again.\n");
        }

    } while (choice != 4);

    return 0;
}